import { Component, Input, OnInit } from '@angular/core';
import { Label } from 'ng2-charts';
import { ChartDataSets, ChartOptions, ChartType, Chart } from 'chart.js';
import * as pluginDataLabels from 'chartjs-plugin-datalabels';
import { IAssessmentGraphData, IUserGraph } from '../../models/reports-data.interface';
import { selectUserReportsGraph } from '../../store/reports.selectors';
import { Store } from '@ngrx/store';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-graph',
  templateUrl: './graph.component.html',
  styleUrls: ['./graph.component.scss']
})
export class GraphComponent implements OnInit {

  dataForGraph$ = this.store.select(selectUserReportsGraph);

  public chartValues = [];
  public chartLabels = [];

  constructor(
    private store: Store,
  ) { }

  ngOnInit(): void {
    this.dataForGraph$.pipe(filter(value => Boolean(value))).subscribe(value => {
      this.chartValues = Object.values(value.data);
      this.chartLabels = Object.keys(value.data);
      this.setDataChart('User Assessment', this.chartLabels, this.chartValues);
    });
  }

  setDataChart(title, chartlabels, chartValues): void {
    let myChart = new Chart('myChart', {
      type: 'bar',
      data: {
        labels: chartlabels,
        datasets: [{
          label: title,
          data: chartValues,
          backgroundColor: [
            'rgba(255, 99, 132, 0.2)',
            'rgba(54, 162, 235, 0.2)',
            'rgba(255, 206, 86, 0.2)',
            'rgba(75, 192, 192, 0.2)',
          ],
          borderColor: [
            'rgba(255, 99, 132, 1)',
            'rgba(54, 162, 235, 1)',
            'rgba(255, 206, 86, 1)',
            'rgba(75, 192, 192, 1)',
          ],
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero: true
            }
          }]
        }
      }
    });
  }
}
