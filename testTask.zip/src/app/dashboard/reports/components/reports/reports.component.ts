import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { loadReport, loadReportGraph } from '../../store/reports.actions';
import { selectUserReports } from '../../store/reports.selectors';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss']
})
export class ReportsComponent implements OnInit {

  arrayOfReports$ = this.store.select(selectUserReports);
  isSelected = false;

  constructor(
    private store: Store,
  ) { }

  ngOnInit(): void {
    this.store.dispatch(loadReport());
  }

  showGraph(id: number): void {
    this.store.dispatch(loadReportGraph({id}));
  }
}
