import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard.component';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { ReportsComponent } from './reports/components/reports/reports.component';
import { ReportsService } from './reports/services/reports.service';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { reportReducer } from './reports/store/reports.reducer';
import { ReportsEffects } from './reports/store/reports.effects';
import { GraphComponent } from './reports/components/graph/graph.component';
import { ChartsModule } from 'ng2-charts';
import { MatButtonModule } from '@angular/material/button';
import { AdminPanelComponent } from './components/admin-panel/admin-panel.component';
import { UserPanelComponent } from './components/user-panel/user-panel.component';

@NgModule({
  declarations: [DashboardComponent, ReportsComponent, GraphComponent, AdminPanelComponent, UserPanelComponent],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    StoreModule.forFeature('reportReducer', reportReducer),
    EffectsModule.forFeature([ReportsEffects]),
    ChartsModule,
    MatButtonModule,
  ],
  providers: [ReportsService]
})
export class DashboardModule { }



