export interface IUserData {
  first_name: string;
  last_name: string;
  role: string;
  token: string;
}
