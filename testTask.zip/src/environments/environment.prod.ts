export const environment = {
  production: true,
  oktaAPI: 'https://dev-6767126.okta.com'
};
